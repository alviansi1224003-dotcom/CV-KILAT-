# CV KILAT Website

Website katalog jasa pembuatan Curriculum Vitae (CV) profesional untuk lamaran kerja.

## Cara Mengunggah ke GitHub Pages

1. Buka [https://github.com](https://github.com) dan login.
2. Buat repository baru bernama `cv-kilat`.
3. Upload file `index.html` ke repository.
4. Masuk ke tab **Settings > Pages**, pilih `main` branch dan folder `/ (root)`.
5. Klik **Save** dan tunggu 1 menit.
6. Situs kamu akan muncul di: `https://username.github.io/cv-kilat/`.

## Kontak

Ubah nomor WhatsApp dan email di dalam file `index.html` sebelum upload.
